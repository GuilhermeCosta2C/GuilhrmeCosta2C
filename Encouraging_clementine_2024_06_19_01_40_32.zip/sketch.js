// Variáveis do jogo
let larguraRaquete = 10;
let alturaRaquete = 80;
let raqueteEsquerda, raqueteDireita;
let bola;
let velocidadeBolaX = 5;
let velocidadeBolaY = 5;
let placarEsquerda = 0;
let placarDireita = 0;

function setup() {
  createCanvas(800, 400);
  raqueteEsquerda = createVector(20, height / 2 - alturaRaquete / 2);
  raqueteDireita = createVector(width - 30, height / 2 - alturaRaquete / 2);
  bola = createVector(width / 2, height / 2);
}

function draw() {
  background(0);
  
  // Desenhar raquetes
  desenharRaquete(raqueteEsquerda.x, raqueteEsquerda.y);
  desenharRaquete(raqueteDireita.x, raqueteDireita.y);
  
  // Desenhar bola
  desenharBola(bola.x, bola.y);
  
  // Movimentar raquete esquerda
  moverRaqueteEsquerda();
  
  // Movimentar raquete direita automaticamente
  moverRaqueteDireitaAuto();
  
  // Movimentar bola
  moverBola();
  
  // Verificar colisões
  verificarColisao();
  
  // Exibir placar
  exibirPlacar();
}

function desenharRaquete(x, y) {
  fill(255);
  rect(x, y, larguraRaquete, alturaRaquete);
}

function desenharBola(x, y) {
  fill(255);
  ellipse(x, y, 20, 20);
}

function moverRaqueteEsquerda() {
  // Mover raquete esquerda com as setas
  if (keyIsDown(UP_ARROW) && raqueteEsquerda.y > 0) {
    raqueteEsquerda.y -= 5;
  } else if (keyIsDown(DOWN_ARROW) && raqueteEsquerda.y < height - alturaRaquete) {
    raqueteEsquerda.y += 5;
  }
}

function moverRaqueteDireitaAuto() {
  // Mover raquete direita automaticamente
  let centroRaqueteDireita = raqueteDireita.y + alturaRaquete / 2;
  if (centroRaqueteDireita < bola.y) {
    raqueteDireita.y += 3;
  } else {
    raqueteDireita.y -= 3;
  }
}

function moverBola() {
  bola.x += velocidadeBolaX;
  bola.y += velocidadeBolaY;
}

function verificarColisao() {
  // Verificar colisão com as raquetes
  if (bola.x <= raqueteEsquerda.x + larguraRaquete && bola.y >= raqueteEsquerda.y && bola.y <= raqueteEsquerda.y + alturaRaquete) {
    velocidadeBolaX *= -1;
  } else if (bola.x >= raqueteDireita.x - larguraRaquete && bola.y >= raqueteDireita.y && bola.y <= raqueteDireita.y + alturaRaquete) {
    velocidadeBolaX *= -1;
  }
  
  // Verificar colisão com as paredes
  if (bola.y <= 0 || bola.y >= height) {
    velocidadeBolaY *= -1;
  }
  
  // Verificar gol
  if (bola.x <= 0) {
    // Ponto para o jogador direito
    placarDireita++;
    reiniciarBola();
  } else if (bola.x >= width) {
    // Ponto para o jogador esquerdo
    placarEsquerda++;
    reiniciarBola();
  }
}

function reiniciarBola() {
  // Resetar a posição da bola
  bola.x = width / 2;
  bola.y = height / 2;
  
  // Resetar a direção da bola
  velocidadeBolaX *= random() > 0.5 ? 1 : -1;
  velocidadeBolaY *= random() > 0.5 ? 1 : -1;
}

function exibirPlacar() {
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(placarEsquerda, width / 4, 50);
  text(placarDireita, width * 3 / 4, 50);
}
function movimentaMinhaRaquete() {
  if(keyIsDown(UP_ARROW)) {
    yRaquete -= 10;
  }
  if(keyIsDown(DOWN_ARROW)) {
    yRaquete += 10;
  }
}

